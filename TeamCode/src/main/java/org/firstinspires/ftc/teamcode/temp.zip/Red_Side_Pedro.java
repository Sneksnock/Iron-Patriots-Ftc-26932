package org.firstinspires.ftc.teamcode;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotorEx;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;

@Autonomous(name = "Red_Side_Pedro", group = "Examples")
public class Red_Side_Pedro extends OpMode {

    /// ---------------- HARDWARE ----------------
    private Follower follower;

    /// ---------------- SHOOTER OBJECT  ----------------
    private shooter_temp shooter;

    /// ---------------- TIMERS ----------------
    private Timer pathTimer, opModeTimer;

    /// ---------------- STATE ----------------
    private int pathState = 0;

    /// ---------------- "WAIT TO SHOOT" + "FOLLOW ONCE" ----------------
    private boolean shotRequested = false;
    private int lastPathState = -1;

    /// ---------------- POSES ----------------
    private final Pose startPose = new Pose(124.311, 121.794, 0.739);
    private final Pose scorePose = new Pose(80, 87.281, 0.712);
    private final Pose line1Pre = new Pose(106.834, 82.316, 0.08);
    private final Pose intake2Pose = new Pose(111.975, 80.288, 0.02);
    private final Pose intake3OutsidePose = new Pose(127.339, 80.754, 0.03);
    private final Pose line2pre = new Pose(47.153, 61.445, 3.070);
    private final Pose intake4Pose = new Pose(29, 60.5, 3.070);
    private final Pose intake5OutsidePose = new Pose(24, 63, 3.070);
    private final Pose intake6Pose = new Pose(18, 60, Math.toRadians(3.070));
    private final Pose line3pre = new Pose(43.750, 41.227, 3.070);
    private final Pose intake7outsidePose = new Pose(29, 39, Math.toRadians(3.070));
    private final Pose intake9Pose = new Pose(16, 36, Math.toRadians(3.070));
    private final Pose leverPose = new Pose(133.681, 57.206, (0.613));

    // ---------------- PATHS ----------------
    private PathChain score1;
    private PathChain l1Pos;
    private PathChain intakeL12;
    private PathChain intakeL13;
    private PathChain score2;
    private PathChain l2Pos;
    private PathChain intakeL21;
    private PathChain intakeL22;
    private PathChain intakeL23;
    private PathChain score3;
    private PathChain l3Pos;
    private PathChain intakeL31;
    private PathChain intakeL33;
    private PathChain score4;
    private PathChain lever;

    @Override
    public void init() {
        pathTimer = new Timer();
        opModeTimer = new Timer();
        opModeTimer.resetTimer();

        follower = Constants.createFollower(hardwareMap);
        buildPaths();
        follower.setStartingPose(startPose);

        /// ---------------- SHOOTER OBJECT INIT ----------------
        shooter = new shooter_temp();
        shooter.init(hardwareMap);
    }

    /// ---------------- FOLLOW PATH ONLY ONCE PER STATE ----------------
    private void followPathOnce(PathChain path) {
        if (pathState != lastPathState) {
            follower.followPath(path);
            lastPathState = pathState;
        }
    }

    /// ---------------- LOOP ----------------
    @Override
    public void loop() {
        follower.update();
        shooter.update();

        try {
            autonomousPathUpdate();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        telemetry.addData("Path State", pathState);
        telemetry.addData("Heading Error", follower.getHeadingError());
        telemetry.addData("angular Velocity", follower.getAngularVelocity());
        telemetry.addData("At Parametric End", follower.atParametricEnd());
        telemetry.addData("Velocity", follower.getVelocity());
        telemetry.addData("Shooter State", shooter.getState());
        telemetry.update();
    }

    /// ---------------- FSM ----------------
    public void autonomousPathUpdate() throws InterruptedException {
        switch (pathState) {
            case 0:
                followPathOnce(score1);
                if (!Schmovin()) {
                    if (!shotRequested) {
                        shooter.shoot();
                        shotRequested = true;
                    }
                    if (shooter.getState() == shooter_temp.ShootingState.IDLE) {
                        shotRequested = false;
                        pathState = 1;
                    }
                }
                break;

            case 1:
                shooter_temp.ie.setPower(.75);
                followPathOnce(l1Pos);
                if (!Schmovin()) {
                    pathState = 2;
                }
                break;

            case 2:
                shooter_temp.ie.setPower(.75);
                followPathOnce(intakeL12);
                if (!Schmovin()) {
                    pathState = 3;
                }
                break;

            case 3:
                shooter_temp.ie.setPower(.75);
                followPathOnce(intakeL13);
                if (!Schmovin()) {
                    pathState = 4;
                }
                break;

            case 4:
                shooter_temp.ie.setPower(0.0);
                followPathOnce(score2);
                if (!Schmovin()) {
                    if (!shotRequested) {
                        shooter.shoot();
                        shotRequested = true;
                        pathState = 5;
                    }
                    break;
                }
                break;
        }
    }

    /// ---------------- HELPERS ----------------
    public boolean Schmovin() {
        return Math.abs(follower.getHeadingError()) > .98 ||
                !follower.atParametricEnd() ||
                follower.getVelocity().getMagnitude() > 0.90 ||
                Math.abs(follower.getAngularVelocity()) > .90;
    }

    ///---------------- PATH BUILDER ----------------
    public void buildPaths() {
        score1 = follower.pathBuilder()
                .addPath(new BezierLine(startPose, scorePose))
                .setLinearHeadingInterpolation(startPose.getHeading(), scorePose.getHeading())
                .build();

        l1Pos = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, line1Pre))
                .setLinearHeadingInterpolation(scorePose.getHeading(), line1Pre.getHeading())
                .build();

        intakeL12 = follower.pathBuilder()
                .addPath(new BezierLine(line1Pre, intake2Pose))
                .setLinearHeadingInterpolation(line1Pre.getHeading(), intake2Pose.getHeading())
                .build();

        intakeL13 = follower.pathBuilder()
                .addPath(new BezierLine(intake2Pose, intake3OutsidePose))
                .setLinearHeadingInterpolation(intake2Pose.getHeading(), intake3OutsidePose.getHeading())
                .build();

        score2 = follower.pathBuilder()
                .addPath(new BezierLine(intake3OutsidePose, scorePose))
                .setLinearHeadingInterpolation(intake3OutsidePose.getHeading(), scorePose.getHeading())
                .build();

        l2Pos = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, line2pre))
                .setLinearHeadingInterpolation(scorePose.getHeading(), line2pre.getHeading())
                .build();

        intakeL21 = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, intake4Pose))
                .setLinearHeadingInterpolation(scorePose.getHeading(), intake4Pose.getHeading())
                .build();

        intakeL22 = follower.pathBuilder()
                .addPath(new BezierLine(intake4Pose, intake5OutsidePose))
                .setLinearHeadingInterpolation(intake4Pose.getHeading(), intake5OutsidePose.getHeading())
                .build();

        intakeL23 = follower.pathBuilder()
                .addPath(new BezierLine(intake5OutsidePose, intake6Pose))
                .setLinearHeadingInterpolation(intake5OutsidePose.getHeading(), intake6Pose.getHeading())
                .build();

        score3 = follower.pathBuilder()
                .addPath(new BezierLine(intake6Pose, scorePose))
                .setLinearHeadingInterpolation(intake6Pose.getHeading(), scorePose.getHeading())
                .build();

        l3Pos = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, line3pre))
                .setLinearHeadingInterpolation(scorePose.getHeading(), line3pre.getHeading())
                .build();

        intakeL31 = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, intake7outsidePose))
                .setLinearHeadingInterpolation(scorePose.getHeading(), intake7outsidePose.getHeading())
                .build();

        intakeL33 = follower.pathBuilder()
                .addPath(new BezierLine(intake7outsidePose, intake9Pose))
                .setLinearHeadingInterpolation(intake7outsidePose.getHeading(), intake9Pose.getHeading())
                .build();

        score4 = follower.pathBuilder()
                .addPath(new BezierLine(intake9Pose, scorePose))
                .setLinearHeadingInterpolation(intake9Pose.getHeading(), scorePose.getHeading())
                .build();

        lever = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, leverPose))
                .setLinearHeadingInterpolation(scorePose.getHeading(), leverPose.getHeading())
                .build();
    }
}
