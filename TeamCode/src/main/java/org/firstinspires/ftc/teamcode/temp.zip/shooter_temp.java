package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

public class shooter_temp {
    public static CRServo Lfeeder, Rfeeder;
    public static DcMotorEx Lsh, Rsh;
    public static DcMotorEx ie;
    public static ElapsedTime stateTimer = new ElapsedTime(ElapsedTime.Resolution.MILLISECONDS);

    /// -----------  SHOOTING STATES ---------
    public enum ShootingState {
        IDLE,
        SPIN_UP,
        LAUNCH1,
        LAUNCH2,
        LAUNCH3,
        LAUNCH4,
        END;
    }

    private static ShootingState shootingState = ShootingState.IDLE;

    /// ---------- FEEDER, INTAKE LOGIC  ----------
    public static double LfeederP = .65;  //IRL = right feeder maximum power
    public static double RfeederP = 1.0;  //IRL = left feeder maximum power
    public static double LfeederT = 500;  //IRL = right feeder maximum time currently
    public static double RfeederT = 750;  //IRL = left feeder maximum time currently
    public static double ieP = .75;       // Intake power
    public static double off = -0.05;

    /// ---------- LAUNCHER CONSTANTS ----------
    public static double CLOSE_VELOCITY = 1125;
    public static double VELOCITY_TOLERANCE = 15;
    public static double SPIN_TIME = 2000;
    public static int ShotsRemaining = 0;

    ///  ---------- HWMap ----------
    public void init(HardwareMap hwMap) {
        ie = hwMap.get(DcMotorEx.class, "intake");
        Lsh = hwMap.get(DcMotorEx.class, "left_launcher");
        Rsh = hwMap.get(DcMotorEx.class, "right_launcher");
        Lfeeder = hwMap.get(CRServo.class, "left_feeder");
        Rfeeder = hwMap.get(CRServo.class, "right_feeder");

        Rsh.setDirection(DcMotorEx.Direction.REVERSE);
        Rfeeder.setDirection(DcMotorSimple.Direction.REVERSE);
        ie.setDirection(DcMotorSimple.Direction.REVERSE);
        Lsh.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        Rsh.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);

        shootingState = ShootingState.IDLE;
        ShotsRemaining = 0;
        Lfeeder.setPower(off);
        Rfeeder.setPower(off);
        ie.setPower(0);
    }
    private static boolean shootRequestActive = false;
    private static boolean leftIdleOnce = false;

    public static boolean isBusy() {
        return shootRequestActive; // "busy" from request start until we finish and clear it
    }

    public static boolean shoot() {
        if (!shootRequestActive) {
            ShotsRemaining = 1;
            shootRequestActive = true;
            leftIdleOnce = false;
        }

        // confirm we actually started (left IDLE)
        if (shootRequestActive && shootingState != ShootingState.IDLE) {
            leftIdleOnce = true;
        }

        // done only after we left IDLE at least once and returned
        if (shootRequestActive && leftIdleOnce && shootingState == ShootingState.IDLE) {
            shootRequestActive = false;
            return true;
        }

        return false;
    }


    public ShootingState getState() {
        return shootingState;
    }

    /// ---------- STATE MACHINE ----------
    public static void update() {
        boolean atSpeed = Math.abs(Lsh.getVelocity() - CLOSE_VELOCITY) <= VELOCITY_TOLERANCE &&
                Math.abs(Rsh.getVelocity() - CLOSE_VELOCITY) <= VELOCITY_TOLERANCE;

        switch (shootingState) {
            case IDLE:
                if (ShotsRemaining > 0) {
                    Lfeeder.setPower(off);
                    Rfeeder.setPower(off);
                    ie.setPower(ieP);
                    Lsh.setVelocity(CLOSE_VELOCITY);
                    Rsh.setVelocity(CLOSE_VELOCITY);
                    stateTimer.reset();
                    shootingState = ShootingState.SPIN_UP;
                } else {
                    Lfeeder.setPower(off);
                    Rfeeder.setPower(off);
                    ie.setPower(0);
                }
                break;

            case SPIN_UP:
                if (atSpeed || stateTimer.milliseconds() >= SPIN_TIME) {
                    Lfeeder.setPower(LfeederP);
                    stateTimer.reset();
                    shootingState = ShootingState.LAUNCH1;
                }
                break;

            case LAUNCH1:
                if (stateTimer.milliseconds() >= LfeederT) {
                    Lfeeder.setPower(off);
                    Rfeeder.setPower(RfeederP);
                    stateTimer.reset();
                    shootingState = ShootingState.LAUNCH2;
                }
                break;

            case LAUNCH2:
                if (stateTimer.milliseconds() >= RfeederT) {
                    Rfeeder.setPower(off);
                    Lfeeder.setPower(LfeederP);
                    ShotsRemaining--;
                    stateTimer.reset();
                    shootingState = ShootingState.LAUNCH3;
                }
                break;

            case LAUNCH3:
                if (stateTimer.milliseconds() >= LfeederT) {
                    Lfeeder.setPower(off);
                    Rfeeder.setPower(RfeederP);
                    ShotsRemaining--;
                    stateTimer.reset();
                    shootingState = ShootingState.LAUNCH4;
                }
                break;

            case LAUNCH4:
                if (stateTimer.milliseconds() >= RfeederT) {
                    Rfeeder.setPower(off);
                    Lfeeder.setPower(LfeederP);
                    ShotsRemaining--;
                    stateTimer.reset();
                    shootingState = ShootingState.END;
                }
                break;

            case END:
                if (stateTimer.milliseconds() >= LfeederT) {
                    ShotsRemaining--;
                    stateTimer.reset();
                    shootingState = ShootingState.IDLE;
                }
                break;
        }
    }
}
